

console.log('From webpack');

export default 999999;