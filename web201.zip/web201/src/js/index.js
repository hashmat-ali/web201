//firebase credential
//email:hashmat@organicfood.com
//password: OrganicFood

// import firebase from 'firebase';
// import './functions/firebase.common'

// import num from "./test";
import axios from 'axios';
require.context("../img/", true, /\.(png|svg|jpg|gif)$/);
import style from "../_scss/main.scss"
import Navigation from "./models/Navigation";
import Product from "./models/Product";
import Category from "./models/Category";
import * as navigationView from './views/navigationView';
import * as productView from './views/productView';
import * as categoryView from './views/categoryView';
import './components/accordion.component';

// import './components/sticky.navigation';





// import x from './components/carousel.component';

// import { Navigation } from './components/navigation.component';
// import { Products } from './components/products.componet';
import { firebaseUpload } from './functions/utils/firebase.upload'



// const nav = new NavigationComponent();
// nav.getNavigation();
// new NavigationComponent().getNavigation();
// new ProductsComponent().getProducts();
//firebaseUpload();

const state = {};

/*
Init Controller
*/

// class IndexControoler {
//     init() {
//         getNavigation();
//     }
// }

const init = async () => {

    //Prepare the UI - start the loading spinner
    //debugger;
    state.navigation = new Navigation();
    state.category = new Category();

    //await state.category.getResultsJson();

    await state.navigation.getResults();
    console.log(state.navigation.Result);
    navigationView.render(state.navigation.Result);

    await state.category.getResults();
    categoryView.render(state.category.Result);

    //console.log(state.category.Result);
    //state.products = new Product();
    // axios.all([state.navigation.getResults(), state.category.getResults()])
    //     .then(axios.spread(function (navigationResults, categoryResults) {
    //         navigationView.render(navigationResults.data);
    //         categoryView.render(categoryResults.data);
    //         console.log(categoryResults.data)
    //     }));
}

//window.addEventListener('load', init);










