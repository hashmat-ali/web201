import axios from 'axios';

export default class Product {
    // constructor() {

    // }
    getResults() {
        return axios
            .get("https://organic-food-23e7c.firebaseio.com/categories.json")
    }
}   
