import axios from 'axios';
import firebase from 'firebase';
import '../functions/firebase.common'
import FireBaseUtility from "../functions/helpers/util.firebase";

export default class Navigation {

    // getResults() {
    //     return axios
    //         .get("https://organic-food-23e7c.firebaseio.com/navigation.json")
    // }

    async getResults() {
        const navigationRef = firebase.database().ref('navigation');
        await navigationRef.once('value').then(value => {
            if (value.exists() && value.hasChildren()) {
                this.Result = value.val();
            }
        });
    }
}   
