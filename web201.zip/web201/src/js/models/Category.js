import axios from 'axios';
import firebase from 'firebase';
import '../functions/firebase.common'
import FireBaseUtility from "../functions/helpers/util.firebase";

export default class Category {
    constructor() {
        this.fbUtility = new FireBaseUtility();
    }
    // async getResultsJson() {
    //     const res = await axios
    //         .get("https://organic-food-23e7c.firebaseio.com/categories.json");
    //     this.Result = res.data;

    // }

    async getResults() {
        const categoriesRef = firebase.database().ref('categories');
        var data = [];
        await categoriesRef.once('value').then(value => {
            if (value.exists() && value.hasChildren()) {
                value.forEach(_child => {
                    data.push({ key: _child.key, data: _child.val() })
                })
                this.Result = data;
                console.log(this.Result);
            }
        });
    }
}   
