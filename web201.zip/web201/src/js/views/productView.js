
import hbsProducts from "../templates/products.hbs";

export const render = (context) => {

    //change the code to categoryView.js

    //console.log(context);
    const productsTemplateHTML = hbsProducts({
        categories: context
    });
    //console.log(productsTemplateHTML)
    document.getElementById('hbs-categories').innerHTML = productsTemplateHTML;
}