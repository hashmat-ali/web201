import hbsCategory from "../templates/categories.hbs";

export const render = (context) => {
    //change the code to categoryView.js
    console.log(context);
    const categoriesHTML = hbsCategory({ categories: context });
    //console.log(categoriesHTML)
    document.getElementById('hbs-categories').innerHTML = categoriesHTML;
}