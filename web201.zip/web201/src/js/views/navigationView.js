
import hbsHeaderNav from "../templates/header.navigation.hbs";

export const render = (context) => {
    //console.log(navigation);
    // const nav = [{
    //     title: "About Us",
    //     link: "/link"
    // },
    // {
    //     title: "About Us",
    //     link: "/link"
    // }]

    //console.log(context);
    const navigationTemplateHTML = hbsHeaderNav({ navs: context });
    //console.log(navigationTemplateHTML);
    document.getElementById('hbs-nav').innerHTML = navigationTemplateHTML;
}