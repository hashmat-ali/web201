import firebase from 'firebase';
import '../firebase.common'

export const firebaseUpload = () => {

    //Firebase data upload
    // var navigation = firebase.database().ref('navigation');
    // console.log(navigation);
    // var navigation = firebase.database().ref("navigation/");

    // navigation.set({
    //     Home: {
    //         title: "Home",
    //         Link: "/home"
    //     },
    //     Shop: {
    //         title: "Shop",
    //         Link: "/shop"
    //     },
    //     Vegetable: {
    //         title: "Vegetable",
    //         Link: "/Vegetable"
    //     },
    //     Fruit: {
    //         title: "Fruit",
    //         Link: "/fruit"
    //     },
    //     Dried: {
    //         title: "Dried",
    //         Link: "/dried"
    //     },
    //     AboutUs: {
    //         title: "About Us",
    //         Link: "/aboutus"
    //     }
    // });

    var db = firebase.database().ref();
    //var products = db.child('products')
    // products.once('value', function (snapshot) {
    //     if (snapshot.exists() && snapshot.hasChildren()) {
    //         products.remove();
    //         db.child('products').update(null);
    //         // snapshot.forEach(function (childSnapshot) {
    //         //     var key = childSnapshot.key;
    //         //     console.log(key);
    //         //     products.child(key).remove();
    //         // })
    //     }
    // });

    // var mainCategoryChild = db.child('main-category');
    const categoriesData = [
        {
            data: {
                title: "Shops"
            },
            sub_categories: [
                {
                    data: {
                        title: "Atta",
                    },
                    products: [
                        {
                            title: "Atta Whole Wheat",
                            amount: 343,
                            discount: true,
                            discountPercent: 5,
                            short_description: "Atta Whole Wheat 10 Kg pack",
                            type: "veg"
                        },
                        {
                            title: "Atta Whole Wheat",
                            amount: 343,
                            discount: true,
                            discountPercent: 5,
                            short_description: "Atta Whole Wheat 10 Kg pack",
                            type: "veg"
                        },
                        {
                            title: "Atta Multigrains",
                            amount: 265,
                            discount: true,
                            discountPercent: 5,
                            short_description: "Atta Multigrains 10 Kg pack",
                            type: "veg"
                        },
                        {
                            title: "Atta Select",
                            amount: 249,
                            discount: true,
                            discountPercent: 5,
                            short_description: "Atta Select 10 Kg pack",
                            type: "veg"
                        },
                        {
                            title: "Atta Chakki Fresh",
                            amount: 171,
                            discount: false,
                            discountPercent: 5,
                            short_description: "Atta Chakki Fresh 10 Kg pack",
                            type: "veg"
                        }
                    ]


                }
                // {
                //     title: "Dry Fruits"

                // },
                // {
                //     title: "Masala"
                // }
            ]
        }
        // {
        //     title: "Fruits",
        //     sub_category: [
        //         {
        //             title: "Exotic Fruits"
        //         },
        //         {
        //             title: "Fresh Fruits"
        //         }
        //     ]
        // },
        // {
        //     title: "Vegetable",
        //     sub_category: [
        //         {
        //             title: "Veggies"
        //         },
        //         {
        //             title: "Herbs"
        //         }
        //     ]
        // }
    ]

    var categoriesRef = db.child('categories')
    var subCategoriesRef = db.child('sub-categories')
    var productsRef = db.child('products')
    categoriesData.forEach(category => {
        categoriesRef.push(category.data)
        categoriesRef.on('child_added', function (data) {
            console.log('Main Category called');
            addSubCategory(data.key, category.sub_categories);
        });
    });

    function addSubCategory(mainCategoryKey, subCategories) {
        console.log(mainCategoryKey, subCategories);
        subCategories.forEach(function (subCategory) {
            subCategoriesRef.push(subCategory.data)
            subCategoriesRef.on('child_added', function (data) {
                var updates = {};
                updates['/categories/' + mainCategoryKey + '/' + data.key] = true;
                db.update(updates)
                addProducts(mainCategoryKey, data.key, subCategory.products);
            });
        });
    }

    function addProducts(mainCategoryKey, subCategoryKey, products) {
        console.log("products called");
        console.log(mainCategoryKey, subCategoryKey, products);

        products.forEach(product => {
            productsRef.push(product);
            console.log(product);
            productsRef.on('child_added', function (data) {
                var updates = {};
                updates['/sub-categories/' + subCategoryKey + '/' + data.key] = true;
                db.update(updates)
            });
        });
    }




    // var categories = firebase.database().ref('categories');

    // categories.on('child_added', function(data) {
    //     addSubCategory(data.key, data.val().sub_category);
    // });

    // function addSubCategory(key, subCategory){
    //     var subCategories = firebase.database().ref('sub-categories');
    //     subCategories.push()


    // }


    // var subcategories = db.child('sub-categories')
    // const data = [
    //     {
    //         title: "Atta"
    //     },
    //     {
    //         title: "Dry Fruits"
    //     },
    //     {
    //         title: "Masala"
    //     }
    // ]

    // data.forEach(category => {
    //     categories.push(category)

    // });


    // let data = [
    //     {
    //         title: "Cheese Butter Burger",
    //         price: 78.99,
    //         short_description: "Cheese Butter Burger",
    //         category: "Grocery"
    //     },
    //     {
    //         title: "Chana Dal",
    //         price: 57.55,
    //         category: "Grocery",
    //         short_description: "Chana Dal"
    //     },
    //     {
    //         title: "Mushroom Burger",
    //         price: 67.55,
    //         category: "Grocery",
    //         short_description: "Mushroom Burger"
    //     }
    // ];

    //data.forEach(product => products.push(product));
}