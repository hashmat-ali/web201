import firebase from 'firebase';
import './firebase.common'
import axios from 'axios';
import hbsProducts from "../templates/products.hbs";
import FireBaseUtility from "./helpers/util.firebase";


const productsRef = firebase.database().ref('products');

// const snapshotToArray = (snapshot) => {
//     let returnedArray = [];
//     snapshot.forEach(function (childSnapshot) {
//         var item = childSnapshot.val();
//         item.key = childSnapshot.key;
//         returnedArray.push(item);
//     });
//     return returnedArray;
// }

export class ProductService {

    constructor() {
        this.fbUtility = new FireBaseUtility();
    }

    getProducts() {


        //let navigation = [];
        // navigationRef.once('value', function (snapshot) {
        //     //console.log(snapshot);
        //     console.log(snapshotToArray(snapshot));
        //     render(snapshotToArray(snapshot));
        // });

        productsRef.once('value').then(value => {
            this.products = this.fbUtility.snapshotToArray(value);
            this.render(this.products);
        })

        //this.render(snapshotToArray(value));


        // this.render(navigation);


        // axios
        //     .get("https://organic-food-23e7c.firebaseio.com/navigation.json")
        //     //.then(response => this.render(new FirebaseUtility().snapshotToArray(response.data)))
        //     .then(response => this.render(response.data))
        //     .catch(error => {
        //         console.log(error);
        //     });
    }

    render(prods) {
        console.log("Logging firebase");
        // const nav = [{
        //     title: "About Us",
        //     link: "/link"
        // },
        // {
        //     title: "About Us",
        //     link: "/link"
        // }]

        //const navigationTemplateHTML = hbsHeaderNav(nav);
        const productsTemplateHTML = hbsProducts({ products: prods });
        document.getElementById('hbs-featured-items').innerHTML = productsTemplateHTML;
    }
}
