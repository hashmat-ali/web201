import firebase from 'firebase';
import './firebase.common'
import axios from 'axios';
import hbsHeaderNav from "../templates/header.navigation.hbs";
import { FirebaseUtility } from "./helpers/util.firebase";


const navigationRef = firebase.database().ref('navigation/');

const snapshotToArray = (snapshot) => {
    let returnedArray = [];
    snapshot.forEach(function (childSnapshot) {
        var item = childSnapshot.val();
        item.key = childSnapshot.key;
        returnedArray.push(item);
    });
    return returnedArray;
}



export class NavigationService {

    async getNavigationList() {

        const navigationRef = firebase.database().ref('navigation/');

        // navigationRef.once('value').then(value => {
        //     console.log(snapshotToArray(value));
        //     this.render(snapshotToArray(value));
        // })

        //this.render(snapshotToArray(value));

        await axios
            .get("https://organic-food-23e7c.firebaseio.com/navigation.json")
            //.then(response => this.render(new FirebaseUtility().snapshotToArray(response.data)))
            //.then(response => this.render(response.data))
            .then(response => this.results = response.data)
            .catch(error => {
                console.log(error);
            });
    }

    render(navigation) {
        console.log("Logging firebase");
        //console.log(navigation);
        // const nav = [{
        //     title: "About Us",
        //     link: "/link"
        // },
        // {
        //     title: "About Us",
        //     link: "/link"
        // }]

        //const navigationTemplateHTML = hbsHeaderNav(nav);
        const navigationTemplateHTML = hbsHeaderNav({ navs: navigation });

        //console.log(navigationTemplateHTML);
        document.getElementById('hbs-header').innerHTML = navigationTemplateHTML;
    }
}
