import firebase from 'firebase';

const config = {
    apiKey: "AIzaSyDhtfxYepwHErfZ-TrjEj0fhpoIjEM2ng4",
    authDomain: "organic-food-23e7c.firebaseapp.com",
    databaseURL: "https://organic-food-23e7c.firebaseio.com",
    projectId: "organic-food-23e7c",
    storageBucket: "organic-food-23e7c.appspot.com",
    messagingSenderId: "412513258853"
};

// Initialize Firebase
firebase.initializeApp(config);