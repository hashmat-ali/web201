// import firebase from 'firebase';
// import '../../firebase/firebase.common';

// //let fbNavigation = [];

// let navigationRef = firebase.database().ref('navigation/');
// //const snapshotToArray = snapshot => Object.entries(snapshot).map(e => Object.assign(e[1], { key: e[0] }));

// function snapshotToArray(snapshot) {
//     var returnedArray = [];
//     snapshot.forEach(function (childSnapshot) {
//         var item = childSnapshot.val();
//         item.key = childSnapshot.key;
//         returnedArray.push(item);
//     });
//     return returnedArray;
// };



// export class FBNavigation {
//     constructor() {

//     }
//     getNavigation{
//     let navigation = [];
//     navigationRef.once('value', function (snapshot) {
//         navigation = snapshotToArray(snapshot);
//         console.log('from Navigation');
//         console.log(navigation);
//     });
//     return navigation;
// }
// }

// // snapshot.forEach(function (childSnapshot) {
// //     var childKey = childSnapshot.key;
// //     var childData = childSnapshot.val();
// //     console.log(childKey, childData)
// // });