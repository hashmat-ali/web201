import { NavigationService } from "../functions/navigation.firebase";
import headerNavigationTemplate from "../templates/header.navigation.hbs";

export class NavigationComponent {
    constructor() {
        this.navigationService = new NavigationService();
    }
    getNavigation() {
        this.results = this.navigationService.getNavigationList();
        console.log(this.results);
    }
}



