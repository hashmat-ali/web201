import $ from "jquery";

const header = $(".header");
const sticky = "header__sticky";
const offsetHeight = $('.header').height();

// $(window).scroll(function () {
//     if ($(this).scrollTop() > offsetHeight) {
//         header.addClass(sticky);
//     } else {
//         header.removeClass(sticky);
//     }
// });

// $(window).scroll(() => {
//     debugger;
//     if ($(this).scrollTop() > offsetHeight) {
//         header.addClass(sticky);
//     } else {
//         header.removeClass(sticky);
//     }
// })

$(window).scroll(function () {
    if ($(window).scrollTop() >= offsetHeight) {
        //debugger;
        header.addClass(sticky);
    }
    else {
        header.removeClass(sticky);
    }
});