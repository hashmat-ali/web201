import { ProductService } from "../functions/product.firebase";

export class ProductsComponent {
    constructor() {
        this.productService = new ProductService();
    }
    getProducts() {
        this.productService.getProducts();
    }
}
