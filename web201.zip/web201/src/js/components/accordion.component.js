import $ from 'jquery';

$(document).ready(function () {
    $(document).on('click', '.accordion__btn', function (event) {
        var target = event.target;
        $(target).toggleClass('accordion_active');
        var panel = $(this).next();
        if ($(panel).is(':visible')) {
            $(panel).hide();
        }
        else {
            $(panel).show();
        }
    });
});